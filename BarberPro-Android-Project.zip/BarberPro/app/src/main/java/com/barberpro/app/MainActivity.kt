package com.barberpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101010)
private val Panel = Color(0xFF1B1B1B)
private val Panel2 = Color(0xFF242424)
private val Gold = Color(0xFFD7B46A)
private val Muted = Color(0xFFAAAAAA)
private val Cream = Color(0xFFF5EBD5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BarberProApp() }
    }
}

@Composable
fun BarberProApp() {
    var tab by remember { mutableStateOf("خانه") }
    var selectedService by remember { mutableStateOf("کوتاهی مو") }
    var selectedBarber by remember { mutableStateOf("آرمان رضایی") }
    var selectedDay by remember { mutableIntStateOf(25) }
    var selectedTime by remember { mutableStateOf("۱۷:30") }
    var showConfirm by remember { mutableStateOf(false) }
    var showAllServices by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF171717), contentColor = Gold) {
                    val items = listOf(
                        Triple("خانه", Icons.Default.Home, "خانه"),
                        Triple("خدمات", Icons.Default.ContentCut, "خدمات"),
                        Triple("رزرو", Icons.Default.CalendarMonth, "رزرو"),
                        Triple("پروفایل", Icons.Default.Person, "پروفایل")
                    )
                    items.forEach { (label, icon, destination) ->
                        NavigationBarItem(
                            selected = tab == destination,
                            onClick = { tab = destination },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Color(0xFF3A3020),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.padding(padding),
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "page"
            ) { page ->
                when (page) {
                    "خانه" -> HomeScreen(
                        onBook = { tab = "رزرو" },
                        onServices = { tab = "خدمات" },
                        onServiceClick = { selectedService = it; tab = "رزرو" }
                    )
                    "خدمات" -> ServicesScreen(
                        expanded = showAllServices,
                        onToggle = { showAllServices = !showAllServices },
                        onChoose = { selectedService = it; tab = "رزرو" }
                    )
                    "رزرو" -> BookingScreen(
                        service = selectedService,
                        barber = selectedBarber,
                        day = selectedDay,
                        time = selectedTime,
                        onService = { selectedService = it },
                        onBarber = { selectedBarber = it },
                        onDay = { selectedDay = it },
                        onTime = { selectedTime = it },
                        onConfirm = { showConfirm = true }
                    )
                    else -> ProfileScreen()
                }
            }
        }

        if (showConfirm) {
            AlertDialog(
                onDismissRequest = { showConfirm = false },
                containerColor = Panel2,
                title = { Text("درخواست رزرو ثبت شد ✨", color = Gold, textAlign = TextAlign.Right) },
                text = {
                    Text(
                        "این فقط یک پیش‌نمایش نمایشی است.\n\nخدمت: $selectedService\nآرایشگر: $selectedBarber\nتاریخ: $selectedDay آذر\nساعت: $selectedTime",
                        color = Cream, textAlign = TextAlign.Right
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showConfirm = false; tab = "خانه" }) {
                        Text("متوجه شدم", color = Gold)
                    }
                }
            )
        }
    }
}

@Composable
fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Ink),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) { item { Column(content = content) } }
}

@Composable
fun HomeScreen(onBook: () -> Unit, onServices: () -> Unit, onServiceClick: (String) -> Unit) {
    PageColumn {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("BARBERPRO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("استایل تو، امضای تو", color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.size(46.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.NotificationsNone, null, tint = Gold)
            }
        }
        Box(
            Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF514126), Color(0xFF211D16), Color(0xFF171717))))
                .padding(22.dp)
        ) {
            Column(Modifier.align(Alignment.CenterStart)) {
                Text("وقتشه متفاوت باشی", color = Cream, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("تجربه‌ای تازه از آراستگی و استایل", color = Color(0xFFE2D4B7), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onBook, colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(13.dp)) {
                    Text("رزرو نوبت", color = Ink, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Default.ArrowBack, null, tint = Ink, modifier = Modifier.size(17.dp))
                }
            }
            Icon(Icons.Default.ContentCut, null, tint = Color(0x55F5EBD5), modifier = Modifier.align(Alignment.CenterEnd).size(105.dp))
        }
        SectionTitle("خدمات محبوب", "مشاهده همه", onServices)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniService("✂️", "کوتاهی مو", "از ۱۸۰ هزار", modifier = Modifier.weight(1f), onClick = { onServiceClick("کوتاهی مو") })
            MiniService("🧔", "اصلاح ریش", "از ۹۰ هزار", modifier = Modifier.weight(1f), onClick = { onServiceClick("اصلاح ریش") })
        }
        SectionTitle("آرایشگرهای برتر", "همه", onBook)
        BarberCard("AR", "آرمان رضایی", "فید و استایل کلاسیک", "۴.۹")
        BarberCard("MK", "محمد کریمی", "اصلاح تخصصی ریش", "۴.۸")
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalOffer, null, tint = Gold, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("پیشنهاد ویژه", color = Gold, fontWeight = FontWeight.Bold)
                    Text("با اولین رزرو، ۱۵٪ تخفیف نمایشی بگیر!", color = Cream, fontSize = 12.sp)
                }
                Text("15٪", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun SectionTitle(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Cream, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(action, color = Gold, fontSize = 12.sp, modifier = Modifier.clickable { onClick() })
    }
}

@Composable
fun MiniService(emoji: String, title: String, price: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(Panel).clickable { onClick() }.padding(16.dp)
    ) {
        Text(emoji, fontSize = 28.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, color = Cream, fontWeight = FontWeight.Bold)
        Text(price, color = Gold, fontSize = 12.sp)
    }
}

@Composable
fun BarberCard(initials: String, name: String, specialty: String, rating: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Gold, Color(0xFF6B542A)))), contentAlignment = Alignment.Center) {
            Text(initials, color = Ink, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Cream, fontWeight = FontWeight.Bold)
            Text(specialty, color = Muted, fontSize = 12.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Star, null, tint = Gold, modifier = Modifier.size(16.dp))
            Text(rating, color = Cream, fontSize = 12.sp)
        }
    }
}

@Composable
fun ServicesScreen(expanded: Boolean, onToggle: () -> Unit, onChoose: (String) -> Unit) {
    PageColumn {
        Text("خدمات ما", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("جزئیات خدمات و تعرفه‌های نمایشی", color = Muted, fontSize = 13.sp)
        val services = listOf(
            Triple("✂️", "کوتاهی مو", "۱۸۰,۰۰۰ تومان"),
            Triple("🧔", "اصلاح ریش", "۹۰,۰۰۰ تومان"),
            Triple("💈", "فید تخصصی", "۲۲۰,۰۰۰ تومان"),
            Triple("🧖", "پاک‌سازی پوست", "28۰,۰۰۰ تومان"),
            Triple("🧴", "شست‌وشو و حالت‌دهی", "۱۲۰,۰۰۰ تومان"),
            Triple("✨", "پکیج VIP", "۳۹۰,۰۰۰ تومان")
        )
        services.take(if (expanded) services.size else 4).forEach { (emoji, name, price) ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { onChoose(name) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 29.sp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Cream, fontWeight = FontWeight.Bold)
                    Text("حدود 30 تا ۴۵ دقیقه", color = Muted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(price, color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("انتخاب خدمت", color = Muted, fontSize = 10.sp)
                }
            }
        }
        OutlinedButton(onClick = onToggle, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) {
            Text(if (expanded) "نمایش کمتر" else "مشاهده همه خدمات")
        }
    }
}

@Composable
fun BookingScreen(
    service: String, barber: String, day: Int, time: String,
    onService: (String) -> Unit, onBarber: (String) -> Unit,
    onDay: (Int) -> Unit, onTime: (String) -> Unit, onConfirm: () -> Unit
) {
    PageColumn {
        Text("رزرو نوبت", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("چند قدم تا استایل جدیدت فاصله داری", color = Muted, fontSize = 13.sp)
        BookingSection("۱. انتخاب خدمت") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("کوتاهی مو", "اصلاح ریش", "فید تخصصی", "پکیج VIP").forEach {
                    ChoiceChip(it, service == it) { onService(it) }
                }
            }
        }
        BookingSection("۲. انتخاب آرایشگر") {
            listOf("آرمان رضایی", "محمد کریمی", "بدون ترجیح").forEach {
                ChoiceChip(it, barber == it) { onBarber(it) }
            }
        }
        BookingSection("۳. انتخاب روز") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                (25..30).forEach { d ->
                    Column(
                        Modifier.width(55.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (day == d) Gold else Panel2).clickable { onDay(d) }.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(listOf("ش", "ی", "د", "س", "چ", "پ")[(d - 25) % 6], color = if (day == d) Ink else Muted, fontSize = 11.sp)
                        Text(d.toString(), color = if (day == d) Ink else Cream, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        BookingSection("۴. ساعت‌های آزاد") {
            val times = listOf("۱۴:۰۰", "۱۵:30", "۱۷:۰۰", "۱۷:30", "۱۹:۰۰", "۲۰:30")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                times.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { t -> Box(Modifier.weight(1f)) { ChoiceChip(t, time == t) { onTime(t) } } }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("خلاصه انتخاب", color = Gold, fontWeight = FontWeight.Bold)
                Text("$service • $barber", color = Cream, fontSize = 12.sp)
                Text("$day آذر، ساعت $time", color = Muted, fontSize = 11.sp)
            }
            Text("۱۸۰,۰۰۰\nتومان", color = Gold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        Button(onClick = onConfirm, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(16.dp)) {
            Text("تأیید نمایشی رزرو", color = Ink, fontWeight = FontWeight.Bold)
        }
        Text("این نسخه صرفاً نمایشی است و رزرو واقعی انجام نمی‌دهد.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun BookingSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Text(title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        content()
    }
}

@Composable
fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Gold else Panel2,
        contentColor = if (selected) Ink else Cream
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp), fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun ProfileScreen() {
    PageColumn {
        Text("پروفایل من", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF514126), Panel))).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(82.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, tint = Ink, modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("کاربر مهمان", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("به خانواده BarberPro خوش آمدی", color = Color(0xFFE2D4B7), fontSize = 12.sp)
        }
        listOf(
            Icons.Default.CalendarMonth to "نوبت‌های من",
            Icons.Default.FavoriteBorder to "خدمات موردعلاقه",
            Icons.Default.NotificationsNone to "اعلان‌ها",
            Icons.Default.HelpOutline to "راهنما و پشتیبانی",
            Icons.Default.Settings to "تنظیمات"
        ).forEach { (icon, label) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable { }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Gold)
                Spacer(Modifier.width(13.dp))
                Text(label, color = Cream, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronLeft, null, tint = Muted)
            }
        }
        Text("BarberPro • نسخه نمایشی 1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}
